from wtforms import Form, StringField, RadioField, BooleanField, validators
from wtforms.fields import EmailField

class RegisterForm(Form):
    username = StringField('Username', [validators.Length(min=2, max=40), validators.DataRequired()])
    gender = RadioField('Gender', choices=[('F', "Female"), ('M', "Male")])
    email = EmailField('Email', [validators.Length(min=10, max=150), validators.DataRequired()])
    password = StringField('Password', [validators.Length(min=6, max=35), validators.DataRequired])
    repeat_password = StringField('Password', [validators.Length(min=6, max=35), validators.DataRequired])
    tos = BooleanField('Do you agree to the terms and conditions', validators=[validators.DataRequired()])